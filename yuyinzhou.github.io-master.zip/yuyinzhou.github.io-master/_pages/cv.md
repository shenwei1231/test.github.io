---
layout: archive
title: "CV"
permalink: /cv/
author_profile: true
redirect_from:
  - /resume
---

{% include base_path %}
[Link](https://yuyinzhou.github.io/Yuyin_Zhou_cv.pdf)

